from email.mime.application import MIMEApplication
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import smtplib
from django.http import HttpResponse
from django.shortcuts import render
import os
from google.oauth2 import service_account
import google.auth
from google.auth.transport.requests import Request
from google.cloud import storage
from io import BytesIO
import fitz  # PyMuPDF
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import letter
import vertexai
from vertexai.preview.language_models import TextGenerationModel

# Specify the path to your JSON key file
key_path = "C:/Users/dell 3593/Downloads/eco-lane-406916-b2d83cd32195.json"

# Load the credentials
credentials = service_account.Credentials.from_service_account_file(key_path)

# Use the credentials for authentication
os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = key_path  # Set the environment variable

credentials, _ = google.auth.default(
    scopes=["https://www.googleapis.com/auth/cloud-platform"]
)

if credentials and credentials.valid:
    # You are authenticated
    pass
else:
    # Authenticate if not already authenticated
    credentials.refresh(Request())

# Function to create a PDF from text input
def create_text_pdf(text):
    packet = BytesIO()
    can = canvas.Canvas(packet, pagesize=letter)
    can.drawString(100, 750, text)  # Adjust the position and style as needed
    can.save()
    packet.seek(0)
    new_pdf = fitz.open("pdf", packet.read())
    return new_pdf

# Function to merge text PDFs and resume PDF into a single PDF
def merge_pdfs(text_pdfs, resume_pdf):
    output_pdf = fitz.open()
    for text_pdf in text_pdfs:
        output_pdf.insert_pdf(text_pdf)
    output_pdf.insert_pdf(resume_pdf)
    return output_pdf

# Define the modified merge_pdfs function
def merge_pdfs2(pdfs, resume_pdf=None):
    merged_pdf = fitz.open()

    # Add text PDFs
    for pdf in pdfs:
        merged_pdf.insert_pdf(pdf)

    # If a resume PDF is provided, add it
    if resume_pdf:
        merged_pdf.insert_pdf(resume_pdf)

    return merged_pdf

# Function to extract text from a PDF file using PyMuPDF
def extract_text_from_pdf(pdf_path):
    text = ""
    doc = fitz.open(pdf_path)
    for page_num in range(doc.page_count):
        page = doc[page_num]
        text += page.get_text()
    return text

# Function to predict keywords from extracted resume text using Vertex AI
def predict_keywords_from_resume(
    project_id: str,
    model_name: str,
    temperature: float,
    max_decode_steps: int,
    top_p: float,
    top_k: int,
    resume_text: str,
    location: str = "us-central1",
    tuned_model_name: str = "",
):
    # Generate a prompt for keyword extraction
    prompt = f"Extract keywords that provide insights into a person's values, technical skills, and soft skills from this answers document and resume. Look for words or phrases that indicate their core values, such as integrity and teamwork, as well as technical proficiencies like programming languages or data analysis. Additionally, identify soft skills such as communication, leadership, and problem-solving abilities. Provide a comprehensive list of keywords that reflect the individual's qualifications and attributes..\n\nResume Content:\n{resume_text}"

    # Initialize Vertex AI
    vertexai.init(project=project_id, location=location)

    # Load the TextGenerationModel
    model = TextGenerationModel.from_pretrained(model_name)

    if tuned_model_name:
        model = model.get_tuned_model(tuned_model_name)

    # Make a prediction using the generated prompt
    response = model.predict(
        prompt,
        temperature=temperature,
        max_output_tokens=max_decode_steps,
        top_k=top_k,
        top_p=top_p,
    )

    # Extract keywords from the response
    extracted_keywords = response.text.split(', ')  # Assuming keywords are separated by a comma and space

    return extracted_keywords

# Function to generate a self-introduction script using Vertex AI
def generate_introduction_script(
    project_id: str,
    model_name: str,
    temperature: float,
    max_decode_steps: int,
    top_p: float,
    top_k: int,
    resume_text: str,
    keywords: list,
    location: str = "us-central1",
    tuned_model_name: str = "",
):
    # Generate a prompt for script generation
    keyword_string = ', '.join(keywords)
    prompt = f"Generate a self-introduction script for an individual with the following keywords: {keyword_string}. Use these keywords to highlight the individual's strengths and skills based on their resume content:\n\n{resume_text}"

    # Initialize Vertex AI
    vertexai.init(project=project_id, location=location)

    # Load the TextGenerationModel
    model = TextGenerationModel.from_pretrained(model_name)

    if tuned_model_name:
        model = model.get_tuned_model(tuned_model_name)

    # Make a prediction using the generated prompt
    response = model.predict(
        prompt,
        temperature=temperature,
        max_output_tokens=max_decode_steps,
        top_k=top_k,
        top_p=top_p,
    )

    # Extract the generated script from the response
    generated_script = response.text

    return generated_script

from django.http import JsonResponse
from bv import settings
from django.core.files.storage import FileSystemStorage

def homepage(request):
    return render(request, 'index.html')

def getstarted(request):
    return render(request,'getstarted.html')

def questions(request):
    return render(request, 'questions.html')

def question2(request):
    return render(request, 'question2.html')

def question3(request):
    return render(request, 'question3.html')

def analyze(request):
   # Initialize the variable
    resume_pdf_path = ''

    # Use request.GET to get the answers
    question1_text = request.POST.get('text1', 'default')
    question2_text = request.POST.get('text2', 'default')
    question3_text = request.POST.get('text3', 'default')
    question4_text = request.POST.get('text4', 'default')
    question5_text = request.POST.get('text5', 'default')

    # Create a list of answers
    answers = [question1_text, question2_text, question3_text, question4_text, question5_text]

    # Handle the uploaded resume file
    resume_file = request.FILES.get("resume")

    if resume_file:
        # Get the original filename without URL encoding
        original_filename = resume_file.name

        # Store the uploaded file and its path with the original filename
        fs = FileSystemStorage()
        filename = fs.save(original_filename, resume_file)
        request.session['resume_pdf_path'] = fs.url(filename)
        # Update the resume_pdf_path if a file is uploaded
        resume_pdf_path = os.path.join(settings.MEDIA_ROOT, filename)
    else:
        return JsonResponse({"success": False, "message": "No file uploaded."})
    
    # Create PDFs from user-entered text
    text_pdfs = [create_text_pdf(answer) for answer in answers]

    # Open the user's resume PDF from the session
    resume_pdf_path = os.path.join(settings.MEDIA_ROOT, resume_pdf_path)
    resume_pdf = fitz.open(resume_pdf_path)

    # Merge the text PDFs and resume PDF
    merged_pdf = merge_pdfs(text_pdfs, resume_pdf)

    # Create the destination object name based on the resume filename
    resume_filename = os.path.basename(resume_pdf_path)
    destination_blob_name = f"merged_{os.path.splitext(resume_filename)[0]}.pdf"

    # Save the merged PDF to a file (temporarily)
    merged_pdf_path = "merged_resume.pdf"
    merged_pdf.save(merged_pdf_path)

    # Upload the merged PDF to Google Cloud Storage
    bucket_name = 'bvi_mergedfiles1'  # Replace with your GCS bucket name

    storage_client = storage.Client()
    bucket = storage_client.bucket(bucket_name)
    blob = bucket.blob(destination_blob_name)
    blob.upload_from_filename(merged_pdf_path)

    # Extract text from the merged resume PDF
    merged_pdf_text = extract_text_from_pdf(merged_pdf_path)

    # You can now proceed with keyword extraction and script generation using merged_pdf_text

        # Predict keywords from the merged resume PDF using Vertex AI
    keywords = predict_keywords_from_resume(
        project_id="eco-lane-406916",
        model_name="text-bison@001",
        temperature=0.2,
        max_decode_steps=256,
        top_p=0.8,
        top_k=40,
        resume_text=merged_pdf_text,
        location="us-central1",
    )

    # Generate the self-introduction script using extracted keywords
    generated_script = generate_introduction_script(
        project_id="eco-lane-406916",
        model_name="text-bison@001",
        temperature=0.2,
        max_decode_steps=256,
        top_p=0.8,
        top_k=40,
        resume_text=merged_pdf_text,
        keywords=keywords,
    )

    # Pass the extracted keywords and generated script as context data to the template
    context = {
        'success': "Merging, Keyword Extraction, and Script Generation Successful",
        'extracted_keywords': keywords,
        'generated_script': generated_script,
    }

    return render(request, 'analyze.html', context)

# Define the analyze2 view
def analyze2(request):
    # Initialize variables

    # Use request.POST to get the answers
    question1_text = request.POST.get('text1', 'default')
    question2_text = request.POST.get('text2', 'default')
    question3_text = request.POST.get('text3', 'default')
    question4_text = request.POST.get('text4', 'default')
    question5_text = request.POST.get('text5', 'default')

    # Create a list of answers
    answers = [question1_text, question2_text, question3_text, question4_text, question5_text]

    # Create PDFs from user-entered text
    text_pdfs = [create_text_pdf(answer) for answer in answers]

    # Merge the text PDFs
    merged_pdf = merge_pdfs2(text_pdfs)

    # You can now proceed with keyword extraction and script generation using merged_pdf

    # Extract text from the merged PDF
    merged_pdf_text = ""
    for page_num in range(merged_pdf.page_count):
        page = merged_pdf[page_num]
        merged_pdf_text += page.get_text("text")

    # Predict keywords from the merged PDF using Vertex AI
    keywords = predict_keywords_from_resume(
        project_id="eco-lane-406916",
        model_name="text-bison@001",
        temperature=0.2,
        max_decode_steps=256,
        top_p=0.8,
        top_k=40,
        resume_text=merged_pdf_text,
        location="us-central1",
    )

    # Generate the self-introduction script using extracted keywords
    generated_script = generate_introduction_script(
        project_id="eco-lane-406916",
        model_name="text-bison@001",
        temperature=0.2,
        max_decode_steps=256,
        top_p=0.8,
        top_k=40,
        resume_text=merged_pdf_text,
        keywords=keywords,
    )

    # Pass the extracted keywords and generated script as context data to the template
    context = {
        'success': "Keyword Extraction and Script Generation Successful",
        'extracted_keywords': keywords,
        'generated_script': generated_script,
    }

    return render(request, 'analyze.html', context)




def analyze3(request):
   # Initialize the variable
    resume_pdf_path = ''

    # Use request.GET to get the answers
    question1_text = request.POST.get('text1', 'default')
    question2_text = request.POST.get('text2', 'default')
    question3_text = request.POST.get('text3', 'default')
    question4_text = request.POST.get('text4', 'default')
    question5_text = request.POST.get('text5', 'default')

    # Create a list of answers
    answers = [question1_text, question2_text, question3_text, question4_text, question5_text]

    # Handle the uploaded resume file
    resume_file = request.FILES.get("resume")

    if resume_file:
        # Get the original filename without URL encoding
        original_filename = resume_file.name

        # Store the uploaded file and its path with the original filename
        fs = FileSystemStorage()
        filename = fs.save(original_filename, resume_file)
        request.session['resume_pdf_path'] = fs.url(filename)
        # Update the resume_pdf_path if a file is uploaded
        resume_pdf_path = os.path.join(settings.MEDIA_ROOT, filename)
    else:
        return JsonResponse({"success": False, "message": "No file uploaded."})
    
    # Create PDFs from user-entered text
    text_pdfs = [create_text_pdf(answer) for answer in answers]

    # Open the user's resume PDF from the session
    resume_pdf_path = os.path.join(settings.MEDIA_ROOT, resume_pdf_path)
    resume_pdf = fitz.open(resume_pdf_path)

    # Merge the text PDFs and resume PDF
    merged_pdf = merge_pdfs(text_pdfs, resume_pdf)

    # Create the destination object name based on the resume filename
    resume_filename = os.path.basename(resume_pdf_path)
    destination_blob_name = f"merged_{os.path.splitext(resume_filename)[0]}.pdf"

    # Save the merged PDF to a file (temporarily)
    merged_pdf_path = "merged_resume.pdf"
    merged_pdf.save(merged_pdf_path)

    # Upload the merged PDF to Google Cloud Storage
    bucket_name = 'bvi_mergedfiles1'  # Replace with your GCS bucket name

    storage_client = storage.Client()
    bucket = storage_client.bucket(bucket_name)
    blob = bucket.blob(destination_blob_name)
    blob.upload_from_filename(merged_pdf_path)

    # Extract text from the merged resume PDF
    merged_pdf_text = extract_text_from_pdf(merged_pdf_path)

    # You can now proceed with keyword extraction and script generation using merged_pdf_text

        # Predict keywords from the merged resume PDF using Vertex AI
    keywords = predict_keywords_from_resume(
        project_id="eco-lane-406916",
        model_name="text-bison@001",
        temperature=0.2,
        max_decode_steps=256,
        top_p=0.8,
        top_k=40,
        resume_text=merged_pdf_text,
        location="us-central1",
    )

    # Generate the self-introduction script using extracted keywords
    generated_script = generate_introduction_script(
        project_id="eco-lane-406916",
        model_name="text-bison@001",
        temperature=0.2,
        max_decode_steps=256,
        top_p=0.8,
        top_k=40,
        resume_text=merged_pdf_text,
        keywords=keywords,
    )

    # Pass the extracted keywords and generated script as context data to the template
    context = {
        'success': "Merging, Keyword Extraction, and Script Generation Successful",
        'extracted_keywords': keywords,
        'generated_script': generated_script,
    }

    return render(request, 'analyze.html', context)

# views.py

from django.http import JsonResponse, HttpResponseRedirect
from django.core.mail import EmailMessage
from django.shortcuts import render
from django.contrib import messages
#from utils import create_text_pdf, merge_pdfs, extract_text_from_pdf, predict_keywords_from_resume, generate_introduction_script
from google.cloud import storage
import os
from io import BytesIO
import fitz

def send_email(request):
    try:
        # Fetch keywords and generated script from the session
        keywords = request.session.get('extracted_keywords', [])
        generated_script = request.session.get('generated_script', '')

        # Check if keywords and generated script are available in the session
        if not keywords or not generated_script:
            # Handle the case where keywords or generated script are not found in the session
            messages.error(request, 'Keywords or generated script not found in the session.')
            return HttpResponseRedirect('/')

        # Get user's email from the form
        user_email = 'btproject24@gmail.com'

        # Check if user_email is provided
        if not user_email:
            messages.error(request, 'Please enter your email.')
            return HttpResponseRedirect('/')

        # Send email with PDF attachment
        subject = 'Your Keyword Analysis and Introduction Script'
        message = 'Here is the list of keywords and the introduction script generated based on your resume.'
        from_email = 'btproject24@gmail.com'  # Replace with your email address

        # Use the user's entered email as the recipient
        to_email = [user_email]

        # Create a PDF from keywords and script
        pdf_content = f"Keywords: {', '.join(keywords)}\n\nGenerated Script:\n{generated_script}"
        pdf = create_text_pdf(pdf_content)

        # Attach the PDF to the email
        msg = MIMEMultipart()
        msg.attach(MIMEText(message))
        attached_file = MIMEApplication(pdf.read(), _subtype="pdf")
        attached_file.add_header('Content-Disposition', 'attachment', filename='keywords_and_script.pdf')
        msg.attach(attached_file)

        # Set the subject and sender/receiver email addresses
        msg['Subject'] = subject
        msg['From'] = from_email
        msg['To'] = ', '.join(to_email)

        # Initialize the SMTP server and send the email
        smtp = smtplib.SMTP('smtp.gmail.com', 587)
        smtp.starttls()
        smtp.login('btproject24@gmail.com', 'niiy srcv bprm pkcv')  # Replace with your email and app password
        smtp.sendmail(from_email, to_email, msg.as_string())
        smtp.quit()

        # Redirect to the success page
        return HttpResponseRedirect('/emaildisplay/')

    except Exception as e:
        # Log the error or print it for debugging
        print(f"An error occurred while sending email: {e}")
        
        # Handle the error as needed, e.g., redirect to an error page
        messages.error(request, 'An error occurred while sending the email.')
        return HttpResponseRedirect('/')

# def send_email(request):

#     # Fetch keywords and generated script from the session
#     keywords = request.session.get('extracted_keywords', [])
#     generated_script = request.session.get('generated_script', '')

#     # Check if keywords and generated script are available in the session
#     if not keywords or not generated_script:
#         # Handle the case where keywords or generated script are not found in the session
#         messages.error(request, 'Keywords or generated script not found in the session.')
#         return HttpResponseRedirect('/')
    
    
#     user_email = request.POST.get('user_email')
#     # Send email with PDF attachment
#     subject = 'Your Keyword Analysis and Introduction Script'
#     message = 'Here is the list of keywords and the introduction script generated based on your resume.'
#     from_email = 'btproject24@gmail.com'  # Replace with your email address
#     to_email = [user_email]
#     # Create a PDF from keywords and script
#     pdf_content = f"Keywords: {', '.join(keywords)}\n\nGenerated Script:\n{generated_script}"
#     pdf = create_text_pdf(pdf_content)

#     # Attach the PDF to the email
#     email = EmailMessage(subject, message, from_email, to_email)
#     email.attach('keywords_and_script.pdf', pdf.getvalue(), 'application/pdf')
#     email.send()

#     # Redirect to the success page
#     return HttpResponseRedirect('/emaildisplay/')
    
def email_display(request):
    return render(request, 'emaildisplay.html')

